import React, {useState, useEffect } from 'react';
import { User } from '../../models/user.class';
import CreateUserComponent from '../pure/forms/create_user_component';
import UserComponent from '../pure/user_component';


const UserListComponent = () => {
    const [userList, setUserList] = useState([])

    function clearUser(user) {
      let index = userList.indexOf(user)
      let userListTemp = [...userList]
      userListTemp.splice(index,1)
      setUserList(userListTemp)
     }
     function changeState(user) {
      let userListTemp = [...userList]
      user.estado = !user.estado
      setUserList(userListTemp)
     }
     function addUser(user) {
     const userListTemp = [...userList]
     const userRep = userListTemp.find(e=>e.name === user.name || e.email === user.email)
     if(!userRep){
       userListTemp.push(user)
       setUserList(userListTemp) 
     } else {
      alert("el user ya existe")
     }
    }

    return (
        <div className='card'>
        <div className='card-title'>
        <h2 style={{paddingTop:"25px", fontWeight:"bold", color:"green"}}>Listado de Usuarios</h2>
        </div>
        <div className='card-body'>
        <table className='table'>
        <thead>
        <tr>
      <th scope="col">Nombre</th>
      <th scope="col">Email</th>
      <th scope="col">Estado</th>
        </tr>
        </thead>

        <tbody>
       
        {userList.map((user,index)=>{
       
         return(
          <UserComponent
            user={user}
            key={index}
            erase={clearUser}
            change= {changeState}
           ></UserComponent>
         )
     
        })}
    </tbody>
        </table>
        </div>
        <br/>
        <CreateUserComponent
        add={addUser}></CreateUserComponent>
         </div>
    );
};

export default UserListComponent;
