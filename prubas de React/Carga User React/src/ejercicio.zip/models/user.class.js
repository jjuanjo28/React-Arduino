export class User {
    name = ""
    email = ""
    estado = false

    constructor(name,email,estado){
        this.name = name;
        this.email = email;
        this.estado = estado;

    }
}